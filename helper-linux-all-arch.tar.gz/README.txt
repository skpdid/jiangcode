URLCRYPT helper

Binaries:
- helper-linux-amd64 : Linux x86_64/amd64
- helper-linux-arm64  : Linux aarch64/arm64
- helper-linux-armv7  : Linux ARMv7 32-bit

All binaries read the AES-256-GCM key from:
/etc/.zls

The key file must contain exactly 32 bytes and should be root-owned mode 600.

Usage:
  ./helper-linux-amd64 encrypt -text 'https://example.com/private'
  printf '%s' 'CIPHERTEXT' | ./helper-linux-amd64 decrypt

Select the binary using uname -m. Do not run a binary on a different CPU architecture.
